﻿namespace WebApplication1.Models;

public class CommonClass
{
    public List<Product> Products  = new List<Product>();

    public List<Student> Students = new List<Student>();
}
