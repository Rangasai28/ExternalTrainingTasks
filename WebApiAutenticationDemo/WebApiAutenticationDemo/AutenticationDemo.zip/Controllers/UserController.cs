﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiAutenticationDemo.Contracts;
using WebApiAutenticationDemo.Models;

namespace WebApiAutenticationDemo.Controllers;

[Route("api/[controller]")]
[ApiController]
public class UserController : ControllerBase
{
    private readonly IUserService userService;
    
    public UserController(IUserService userService)
    {
        this.userService = userService;
    }


    [AllowAnonymous]
    [HttpPost]
    public async Task<ActionResult> Login(User user)
    {
      var token = await userService.Login(user);
      return Ok(token);
    }

}
