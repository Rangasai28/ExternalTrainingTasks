﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApiAutenticationDemo.Migrations
{
    /// <inheritdoc />
    public partial class UserTab : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
