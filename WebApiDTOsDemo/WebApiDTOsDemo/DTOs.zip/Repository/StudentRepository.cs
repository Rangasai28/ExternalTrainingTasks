﻿using Microsoft.EntityFrameworkCore;
using WebApiDTOsDemo.Data;
using WebApiDTOsDemo.Models;

namespace WebApiDTOsDemo.Repository;

public class StudentRepository : IStudentRepository
{
    private readonly ContextDb ContextClass;

    public StudentRepository(ContextDb context)
    {
        ContextClass = context;
    }

    async Task<IEnumerable<Student>> IStudentRepository.GetAllAsync()
    {
        return await ContextClass.Students.ToListAsync();
    }

    async Task<Student> IStudentRepository.GetByIdAsync(int id)
    {
        return await ContextClass.Students.FindAsync(id);
    }
    async Task<Student> IStudentRepository.AddAsync(Student student)
    {
       ContextClass.Students.Add(student);
        await ContextClass.SaveChangesAsync();
        return student;
    }

    async Task<bool> IStudentRepository.DeleteAsync(int Id)
    {
        if (ContextClass.Students == null )
        {
            return false;
        }
        var product = await ContextClass.Students.FindAsync(Id);
        if (product == null)
        {
            return false;
        }
        ContextClass.Students.Remove(product);
        await ContextClass.SaveChangesAsync();
        return true;
    }





    async Task<bool> IStudentRepository.UpdateAsync(Student student)
    {
        ContextClass.Entry(student).State = EntityState.Modified;
        try
        {
            await ContextClass.SaveChangesAsync();
            return true;
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!StudentExists(student.Id))
            {
                return false;
            }
            else
            {
                throw;
            }
        }
       
    }
    public  bool StudentExists(int id)
    {
        return (ContextClass.Students?.Any(e => e.Id == id)).GetValueOrDefault();
    }
}
