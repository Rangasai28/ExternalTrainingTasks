﻿namespace WebApiDTOsDemo.Models;

public class StudentDtoPut
{
    public string Address { get; set; }

    public string Phone { get; set; }

    public bool IsActive { get; set; }
}
