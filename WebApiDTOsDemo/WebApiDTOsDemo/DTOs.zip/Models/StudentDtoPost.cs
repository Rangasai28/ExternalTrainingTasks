﻿namespace WebApiDTOsDemo.Models;

public class StudentDtoPost
{
    public string FirstName { get; set; }

    public string? MiddleName { get; set; }

    public string LastName { get; set; }

    public string FullName { get; set; }

    public char Gender { get; set; }

    public string DateOfBirth { get; set; }

    public string Address { get; set; }

    public string Phone { get; set; }

    public string GuardianName { get; set; }

}
