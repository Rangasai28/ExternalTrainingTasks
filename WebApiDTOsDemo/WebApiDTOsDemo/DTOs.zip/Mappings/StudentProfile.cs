﻿using AutoMapper;
using WebApiDTOsDemo.Models;

namespace WebApiDTOsDemo.Mappings;

public class StudentProfile : Profile
{
    public StudentProfile()
    {
        CreateMap<Student, StudentDtoGet>();
        CreateMap<StudentDtoPost, Student>();
        CreateMap<StudentDtoPut, Student>();
    }
}
