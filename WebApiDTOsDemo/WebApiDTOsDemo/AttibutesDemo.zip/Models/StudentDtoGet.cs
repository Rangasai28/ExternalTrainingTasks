﻿namespace WebApiDTOsDemo.Models;

public class StudentDtoGet
{
    public string FullName { get; set; }

    public string Phone { get; set; }
    public string CollegeName { get; set; }

    public bool IsActive { get; set; } 
}
