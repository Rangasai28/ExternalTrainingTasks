﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebApiFiltersTask.Contracts;
using WebApiFiltersTask.Filter;
using WebApiFiltersTask.Models;


namespace WebApiFiltersTask.Controllers
{
    
    [Route("api/[controller]")]
    [ApiController]
    [ServiceFilter(typeof(RoleBasedAccessFilter))]
    public class UserController : ControllerBase
    {
        private IUserService userService;

        public UserController(IUserService userService)
        {
            this.userService = userService;
        }

      

        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult> Login(User user)
        {
            var token = await userService.Login(user);
            return Ok(token);
        }



       
        [HttpGet]

        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            var users = await userService.GetUsers();
            return Ok(users);
        }


       
        [HttpGet("getusers")]
        public async Task<ActionResult<IEnumerable<User>>> GetAllUsers()
        {
            var result = await userService.GetAllUsers();
            if(result.Item1 == true)
            {
                return Ok(result.Item2);
            }
            return BadRequest();
           
        }

      
        [HttpGet("delete")]
        public IActionResult DeleteEmployee()
        {
            return Ok("Accessed by Manager");
        }

       
        [HttpGet("adduser")]
        public IActionResult AddUser()
        {
            return Ok("This is accessed by only HR");
        }

        [HttpGet("addproduct")]
        public IActionResult AddProduct()
        {
            return Ok("This is accessed by only HR");
        }

        [HttpGet("updateproduct")]
        public IActionResult UpdateProduct()
        {
            return Ok("This is Accessed by only Employee");
        }

        [HttpGet("updatedetails")]
        public IActionResult UpdateDetails()
        {
            return Ok("This is Accessed by only Employee");
        }
    }
}
