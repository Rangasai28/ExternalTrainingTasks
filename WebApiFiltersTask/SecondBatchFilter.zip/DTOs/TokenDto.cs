﻿namespace WebApiFiltersTask.DTOs;

public class TokenDto
{
    public string Email { get; set; }
    public string Token { get; set; }
    public string IpAdress { get; set; }
}
