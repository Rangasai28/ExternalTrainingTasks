﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using static EmployeeCRUD.Program;

namespace EmployeeCRUD
{
    //Class TO Edit the Fields Of the Employee Details 
    public class UpdateFields
    {
        //Method That Update Employee Name
        public static void UpdateName(ArrayList empList,int id)
        {
            Console.WriteLine("Enter New Name of the Employee:");
            string name  = Console.ReadLine();
            foreach(Employee em in empList)
            {
                if(em.Id == id)
                {
                    em.Name = name;
                }
            }
        }

        //Method That Update Employee Contact Number
        public static void UpdateContactNumber(ArrayList empList,int id)
        {
            Console.WriteLine("Enter New Number of the Employee:");
            int number = Convert.ToInt32(Console.ReadLine());
            foreach (Employee em in empList)
            {
                if (em.Id == id)
                {
                    em.ContactNumber = number;
                }
            }
        }



        //Method That Update Employee Contact Number
        public static void UpdateSalary(ArrayList empList,int id)
        {
            Console.WriteLine("Enter New Salary of the Employee:");
            decimal salary = Convert.ToDecimal(Console.ReadLine());
            foreach (Employee em in empList)
            {
                if (em.Id == id)
                {
                    em.Salary  = salary;
                }
            }
        }
    }
    public  class EmployeeOperations
    {
        public enum UpdateMenu
        {

            Name = 1,
            contactNumber,
            salary,
            Exit
        }


        public  ArrayList EmployeeList = new ArrayList();
        public  void  AddEmployee(Employee employee)
        {
           EmployeeList.Add(employee);
            
        }
        
        public  void DeleteEmployee(int id)
        {
            int index = 0;
            foreach(Employee emp in EmployeeList)
            {
                if(emp.Id == id)
                {
                    index = EmployeeList.IndexOf(emp);

                }
            }
            EmployeeList.RemoveAt(index);

        }

        public  void UpdateEmployee(UpdateMenu value ,int id)
        {
            
            do
            {

                switch (value)
                {
                    case UpdateMenu.Name:
                        UpdateFields.UpdateName(EmployeeList, id);
                        break;
                    case UpdateMenu.contactNumber:
                        UpdateFields.UpdateContactNumber(EmployeeList, id);
                        break;
                    case UpdateMenu.salary:
                        UpdateFields.UpdateSalary(EmployeeList, id);
                        break;
                    case UpdateMenu.Exit:
                        break;
                   
                    default:
                        Console.WriteLine(" Please Enter valid Input");
                        break;
                }
                if (Convert.ToInt32(value) == 6)
                {
                    break;
                }
                value = Program.ReadUpdateField();
            }
            while (Convert.ToInt32(value) != 4);
            Console.WriteLine();

        }

        public string List(int id)
        {
            StringBuilder sb = new();
            foreach(Employee emp in EmployeeList)
            {
               if(emp.Id == id)
                {
                    sb.AppendFormat("Id  = {0}{1}", emp.Id, Environment.NewLine);
                    sb.AppendFormat("Name  = {0}{1}", emp.Name, Environment.NewLine);
                    sb.AppendFormat("ContactNumber  = {0}{1}", emp.ContactNumber, Environment.NewLine);
                    sb.AppendFormat("Salary  = {0}{1}", emp.Salary, Environment.NewLine);
                }
               
            }
            return sb.ToString();  
        }

        public string ListOfEmployees()
        {
            StringBuilder sb = new();
            foreach (Employee emp in EmployeeList)
            {
               
                    sb.AppendFormat("Employee Details of = {0}{1}", emp.Name, Environment.NewLine);
                    sb.AppendFormat("Id  = {0}{1}", emp.Id, Environment.NewLine);
                    sb.AppendFormat("Name  = {0}{1}", emp.Name, Environment.NewLine);
                    sb.AppendFormat("ContactNumber  = {0}{1}", emp.ContactNumber, Environment.NewLine);
                    sb.AppendFormat("Salary  = {0}{1}", emp.Salary, Environment.NewLine);
                    
                

            }
            return sb.ToString();
        }

    }
}
