﻿using System.Collections;
using static EmployeeCRUD.EmployeeOperations;

namespace EmployeeCRUD
{
    internal class Program
    {

        public enum MenuOptions
        {
            Add=1,
            Delete,
            Update,
            List,
            ListAll,
            Exit
        }       
        public static void Main(string[] args)
        {
            
            EmployeeOperations op = new EmployeeOperations();
            MenuOptions uoption = Program.ReadUserOption();
            do
            {

                switch (uoption)
                {
                    case MenuOptions.Add:
                        Program.AddEmp(op);
                        break;
                    case MenuOptions.Delete:
                        Program.DeleteEmp(op);
                        break;
                    case MenuOptions.Update:
                        Program.UpdateEmp(op);
                        break;
                    case MenuOptions.List:
                        Program.getEmployeeDetails(op);
                        break;
                    case MenuOptions.ListAll:
                        Program.getListOfEmployess(op);
                        break;
                    case MenuOptions.Exit:

                        break;
                    default:
                        Console.WriteLine(" Please Enter valid Input");
                        break;
                }
                if (Convert.ToInt32(uoption) == 6)
                {
                    break;
                }
                uoption = Program.ReadUserOption();
            }
            while (Convert.ToInt32(uoption) != 6);
            Console.WriteLine();
        }

        public static MenuOptions ReadUserOption()
        {

            MenuOptions option = MenuOptions.Add;


            do
            {
                Console.WriteLine((int)option + " " + option);
               
                option++;
            }
            while (option <= MenuOptions.Exit);
            Console.WriteLine();
            Console.Write("Select Option From the Above Menu :");
            int userOption = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine();
            return (MenuOptions)userOption;
            
        }


        
        public static UpdateMenu ReadUpdateField()
        {

            UpdateMenu option = UpdateMenu.Name;


            
            do
            {
                Console.WriteLine((int)option + " " + option);
               
                option++;
            }
            while (option <= UpdateMenu.Exit);
            Console.Write("Select Employee Field to be Edited from above Menu :");
            int userOption = Convert.ToInt32(Console.ReadLine());
            
           
            return (UpdateMenu)userOption;
        }

        public static void AddEmp(EmployeeOperations obj)
        {
           // EmployeeOperations oper = new EmployeeOperations();
            Console.WriteLine("Enter  Employee Details");
            Console.Write("Enter Employee Id:");
            int id = Convert.ToInt32(Console.ReadLine());

            foreach(Employee e in obj.EmployeeList)
            {
                if(e.Id == id)
                {
                    Console.WriteLine("Already Exists Enter Another Id");
                   Program.AddEmp(obj);
                }
            }

            Console.Write("Enter Employee Name:");
            string name = Console.ReadLine();

            Console.Write("Enter Employee Contact Number:");
            long contactnumber = Convert.ToInt64(Console.ReadLine());

            Console.Write("Enter Employee Salary:");
            decimal salary = Convert.ToDecimal(Console.ReadLine());

            Employee employee = new Employee(id, name,contactnumber,salary);
           
            obj.AddEmployee(employee);
            Console.WriteLine("Dettails are Added ");
            Console.WriteLine();
           Console.WriteLine( obj.List(id));
        }

        public static void DeleteEmp(EmployeeOperations obj)
        {
            Console.Write("Enter Employees ID To Delete:");
            int id = Convert.ToInt32(Console.ReadLine());
            obj.DeleteEmployee(id);
            
        }

        public static void UpdateEmp(EmployeeOperations obj)
        {
            Console.Write("Enter ID of the Employee To Update:");
            int id = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine(obj.List(id));
            UpdateMenu updateField = Program.ReadUpdateField();

            obj.UpdateEmployee(updateField,id);
            obj.List(id);
        }

        public static void getEmployeeDetails(EmployeeOperations obj)
        {
            Console.Write("Enter Id of the Employee To Get Details:");
            int id = Convert.ToInt32(Console.ReadLine());   
            Console.WriteLine(obj.List(id));
        }

        public static void getListOfEmployess(EmployeeOperations obj)
        {
            Console.WriteLine(obj.ListOfEmployees());
        }
    }
}
