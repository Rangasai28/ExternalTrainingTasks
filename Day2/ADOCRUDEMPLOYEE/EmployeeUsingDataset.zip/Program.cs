﻿namespace ADOCRUDEMPLOYEE
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Menu menu = new Menu();
            menu.readUserOption();
        }
    }
}


