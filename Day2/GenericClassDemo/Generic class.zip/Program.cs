﻿using System.Collections.Generic;
namespace GenericClassDemo
{
    public class Program
    {

        static void Main(string[] args)
        {
            Student s1 = new Student(101, "Bala", 22, 878778, "Fourth", "ECE");
            Student s2 = new Student(102, "Ranga", 32, 478778, "Fourth", "ECE");

            Staff st1 = new Staff(101, "Bala", 42, 878778, 20000m, "LabAssistent");
            Staff st2 = new Staff(102, "Ranga", 32, 878778, 30000m, "LabInCharge");

            MemberList<Student> Studentlist = new MemberList<Student>();
            Studentlist.AddMember(s1);
            Studentlist.AddMember(s2);

            MemberList<Staff> Stafflist = new MemberList<Staff>();
            Stafflist.AddMember(st2);
            Stafflist.AddMember(st1);
            Stafflist.RemoveMember(st2);

            List<Student> stulist = Studentlist.getMemberDetails();
            List<Staff> stlist = Stafflist.getMemberDetails();

            foreach (Student student in stulist)
            {
                Console.WriteLine(student.getDetails());
            }

            foreach (Staff st in stlist)
            {
                Console.WriteLine(st.getDetails());
            }

            

        }

       
       
        
       
        
        


    }
}
