﻿namespace WebApiEFAssignment.Models
{
    public class Customer
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int contactNumber { get; set; }
    }
}
