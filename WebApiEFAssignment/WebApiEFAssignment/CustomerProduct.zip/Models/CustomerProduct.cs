﻿namespace WebApiEFAssignment.Models
{
    public class CustomerProduct
    {
        public int Id { get; set; }

        public int ProductId { get; set; }

        public int CustomerId { get; set; }
    }
}
