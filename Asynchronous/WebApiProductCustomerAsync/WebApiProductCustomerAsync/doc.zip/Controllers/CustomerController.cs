﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApiProductCustomerAsync.Data;
using WebApiProductCustomerAsync.Models;

namespace WebApiProductCustomerAsync.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        readonly ContextClass context;
        public CustomerController(ContextClass contextClass)
        {
            context = contextClass;
        }

        [HttpGet("/Customers")]
        public async Task<ActionResult<IEnumerable<Customer>>> GetCustomers()
        {
            return await context.Customers.ToListAsync();
        }


        [HttpGet("{Id}")]

        public async Task<ActionResult<Product>> GetCustomerById(int Id)
        {
            if (context.Customers == null)
            {
                return NotFound();
            }
            var customer = await context.Customers.FindAsync(Id);
            if (customer == null)
            {
                return NotFound();
            }
            return Ok(customer);

        }

        [HttpPost]
        public async Task<ActionResult<Customer>> PostCustomer(Customer customer)
        {
            context.Customers.Add(customer);
            await context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetCustomerById), new { id = customer.Id }, customer);
        }

        [HttpGet("/details")]
        public async Task<IActionResult> CustomerProductDetails(ContextClass context)
        {
            var customerProducts = await context.CustomerProducts.ToListAsync();

            List<CustomerProductDetails> list = new List<CustomerProductDetails>();

            foreach (var cp in customerProducts)
            {
                CustomerProductDetails cpt = new CustomerProductDetails();
                cpt.Products = new List<Product>();
                Customer customer = await context.Customers.FindAsync(cp.CustomerId);
                Product product = await context.Products.FindAsync(cp.ProductId);
                cpt.customerId = customer.Id;
                cpt.customerName = customer.Name;
                cpt.Products.Add(new Product { Id = cp.ProductId, Name = product.Name,Price = product.Price });
                list.Add(cpt);
            }

            return Ok(list);
        }

    }
}
