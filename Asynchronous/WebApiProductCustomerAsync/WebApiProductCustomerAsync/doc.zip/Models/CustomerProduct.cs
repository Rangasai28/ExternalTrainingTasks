﻿namespace WebApiProductCustomerAsync.Models
{
    public class CustomerProduct
    {
        public int Id { get; set; }

        public int CustomerId { get; set; }

        public int ProductId { get; set; }
    }
}
