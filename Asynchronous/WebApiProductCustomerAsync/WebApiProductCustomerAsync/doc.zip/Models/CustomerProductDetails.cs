﻿namespace WebApiProductCustomerAsync.Models
{
    public class CustomerProductDetails
    {
        public int customerId { get; set; }
        public string customerName { get; set; }

        public List<Product> Products { get; set; }

    }
}
